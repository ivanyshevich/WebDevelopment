/* js/app.js
   Лабораторна № 9 — ініціалізація DayPilot Scheduler
   -------------------------------------------------- */

$(function () {

  /* 1. Створюємо екземпляр Scheduler у контейнері #nav */
  const dp = new DayPilot.Scheduler("nav");

  /* 2. Базові налаштування таймлайна */
  dp.startDate   = DayPilot.Date.today().firstDayOfMonth();   // початок – 1-ше число поточного місяця
  dp.days        = dp.startDate.daysInMonth();                // стільки днів, скільки у місяці
  dp.scale       = "Day";                                     // одна клітинка = 1 день
  dp.cellWidth   = 80;                                        // ширина комірки, щоб влазила повна дата
  dp.timeHeaders = [
    { groupBy: "Month" },
    { groupBy: "Day", format: "yyyy-MM-dd" }
  ];

  /* 2.1. Збільшуємо висоту події, щоб вміщувались два рядки */
  dp.eventHeight = 40;

  /* 3. Обробники дій користувача (клік та створення) */
  dp.onTimeRangeSelected = function (args) {
    const url = `new.php?start=${args.start}&end=${args.end}&resource=${args.resource}`;
    window.open(url, "_blank", "width=420,height=400");
    dp.clearSelection();
  };

  dp.onEventClicked = function (args) {
    const url = `edit.php?id=${args.e.id()}`;
    window.open(url, "_blank", "width=420,height=460");
  };

  /* 4. Додаємо хук для кастомного малювання кожної події */
  dp.onBeforeEventRender = function (args) {
    const e     = args.data;
    // парсимо дати в потрібний формат
    const start = DayPilot.Date.parse(e.start).toString("yyyy-MM-dd");
    const end   = DayPilot.Date.parse(e.end  ).toString("yyyy-MM-dd");
    // малюємо HTML із двома рядками
    args.data.html =
      `<div style="
          padding:4px;
          line-height:1.2;
          font-size:0.85em;
          color:#333;
        ">
        ${e.text}<br/>
        <span style="
          font-size:0.75em;
          color:#555;
        ">${start} – ${end}</span>
      </div>`;
  };

  /* 5. AJAX-завантаження ресурсів (rooms) та подій (reservations) */
  $.when(
    $.getJSON("load_rooms.php"),
    $.getJSON("load_reservations.php")
  ).done(function (roomsData, reservationsData) {

      /* 5.1 Кімнати → dp.resources */
      dp.resources = roomsData[0].map(r => ({
        id:      String(r.id),
        name:    `${r.name} (${r.capacity} місць)`,
        tags:    r
      }));

      /* 5.2 Бронювання → dp.events.list */
      dp.events.list = reservationsData[0].map(e => ({
        id:        String(e.id),
        resource:  String(e.resource),
        start:     e.start,
        end:       e.end,
        text:      e.text,
        barColor:  e.barColor
        // ВАЖЛИВО: не задаємо html тут, його малює onBeforeEventRender
      }));

      /* 6. Останнім кроком — ініціалізуємо Scheduler */
      dp.init();

  }).fail(function () {
      alert("Не вдалося завантажити дані з сервера.");
  });

});